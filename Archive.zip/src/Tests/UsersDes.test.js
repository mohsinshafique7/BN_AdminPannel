import UserDesc from "../components/Description/UserDesc";
import { Route } from "react-router-dom";
import {
  useGetSingleUser,
  useGetAllUsers,
  useDeleteUsers,
  useResetUserPassword,
  useUpdateUsers,
  useGetUserHistory,
} from "../Requests/UsersRequest";
import { useGetAllCompanies } from "../Requests/CompanyRequest";
import React from "react";
import { Provider } from "react-redux";
import store from "../store";
// const renderWithRouter = (renderComponent, route) => {
//   const history = createMemoryHistory();
//   if (route) {
//     history.push(route);
//   }
//   return {
//     ...render(<Router history={history}>{renderComponent}</Router>),
//   };
// };

jest.mock("../Requests/UsersRequest", () => ({
  useGetSingleUser: jest.fn(),
  useGetAllUsers: jest.fn(),
  useDeleteUsers: jest.fn(),
  useResetUserPassword: jest.fn(),
  useUpdateUsers: jest.fn(),
  useGetUserHistory: jest.fn(),
}));
jest.mock("../Requests/CompanyRequest", () => ({
  useGetAllCompanies: jest.fn(),
}));

describe("Update User", () => {
  beforeEach(() => {
    useGetSingleUser.mockImplementation(() => ({}));
    useGetAllUsers.mockImplementation(() => ({}));
    useGetAllCompanies.mockImplementation(() => ({}));
    useDeleteUsers.mockImplementation(() => ({}));
    useResetUserPassword.mockImplementation(() => ({}));
    useUpdateUsers.mockImplementation(() => ({}));
    useGetUserHistory.mockImplementation(() => ({}));
  });

  it("fetches the book data for the given id", () => {
    renderWithRouter(
      () => (
        <Provider store={store}>
          <Route path="/:id">
            <UserDesc />
          </Route>
        </Provider>
      ),
      "/test-book-id"
    );
    expect(useGetSingleUser).toHaveBeenCalledWith("test-book-id");
    expect(useGetAllUsers).toBeCalled();
    expect(useGetAllCompanies).toBeCalled();

    // expect(useGetSingleUser).toHaveBeenCalledWith("test-book-id");
    // expect(useGetSingleUser).toHaveBeenCalledWith("test-book-id");
  });

  describe("while Loading", () => {
    it("render Loader", () => {
      useGetSingleUser.mockImplementation(() => ({
        isLoading: true,
      }));
      useGetAllUsers.mockImplementation(() => ({
        isLoading: true,
      }));
      useGetAllCompanies.mockImplementation(() => ({
        isLoading: true,
      }));
      const { getByTestId } = renderWithRouter(
        () => (
          <Provider store={store}>
            <Route path="/:id">
              <UserDesc />
            </Route>
          </Provider>
        ),
        "/test-book-id"
      );
      expect(getByTestId("loader")).toBeTruthy();
    });
  });
  describe("With Error", () => {
    it.todo("render and Error Message");
  });
  describe("with Data", () => {
    it.todo("render the update User title and form");
    describe("On User Form Submit", () => {
      it.todo("Update the User and navaigate to root");
    });
  });
});
