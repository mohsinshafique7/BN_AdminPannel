import React from "react";
import Template from "../components/Template/Template";
import SuggestionsTabs from "../components/SuggestionsTabs/SuggestionsTabs";

export default () => <Template component={<SuggestionsTabs />} />;
