import React from 'react'
import Template from '../components/Template/Template'
import CoreProductDesc from '../components/Description/CoreProductDesc'

export default () => <Template component={<CoreProductDesc />} />