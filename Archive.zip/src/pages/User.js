import React from 'react'
import Template from '../components/Template/Template'
import UserTabs from '../components/UserTabs/UserTabs'

export default () => <Template component={<UserTabs />} />