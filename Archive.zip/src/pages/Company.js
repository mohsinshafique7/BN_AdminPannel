import React from 'react'
import Template from '../components/Template/Template'
import CompanyTabs from '../components/CompanyTabs/CompanyTabs'

export default () => <Template component={<CompanyTabs />} />