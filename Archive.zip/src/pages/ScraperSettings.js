import React from 'react'
import Template from '../components/Template/Template'
import ScraperSettingsTabs from '../components/ScraperSettingsTabs/ScraperSettingsTabs'

export default () => <Template component={<ScraperSettingsTabs />} />