import React from 'react'
import Template from '../components/Template/Template'
import CreateProductGroup from '../components/CreateForm/CreateProductGroup'

export default () => <Template component={<CreateProductGroup />} />