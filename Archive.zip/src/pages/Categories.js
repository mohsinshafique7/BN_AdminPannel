import React from 'react'
import Template from '../components/Template/Template'
import CategoriesList from '../components/List/CategoriesList'

export default () => <Template component={<CategoriesList />} />