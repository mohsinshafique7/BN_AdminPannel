import React from 'react'
import Template from '../components/Template/Template'
import CompaniesList from '../components/List/CompaniesList'

export default () => <Template component={<CompaniesList />} />