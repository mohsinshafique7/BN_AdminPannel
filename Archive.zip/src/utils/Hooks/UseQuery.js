import React from "react";
const UseQuery = ({ id }) => {
  return <div>HelloWorlds {id * 4}</div>;
};

export default UseQuery;
