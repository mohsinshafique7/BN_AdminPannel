export const STATE_STATUSES = {
  READY: "ready",
  PENDING: "pending",
  ERROR: "error",
  INIT: "init",
};
