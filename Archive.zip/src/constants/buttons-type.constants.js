export const BUTTONS_TYPE = {
  TRANSPARENT: "transparent",
  SOLID: "solid",
  CANCEL: "cancel",
};
